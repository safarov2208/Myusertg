apt install python
pip install requests
pip install telethon
pip install pystyle