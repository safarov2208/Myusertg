Мануал по использованию: https://telegra.ph/Manual-po-ustanovke-i-ispolzovaniyu-HCRGRAM-05-01
